/* Native bridge: runs inside the Mira HUD WebView and swaps the browser-only demo behaviours
   for real Android ones. The Mira page itself (design, 3D head, actions grid) is untouched. */
(function () {
  'use strict';
  if (!window.Android || typeof window.Android.isNative !== 'function') return;
  const A = window.Android;

  // ---- async call plumbing ------------------------------------------------
  const pending = {};
  let seq = 0;
  function reg(fn) { const id = 'c' + (++seq); pending[id] = fn; return id; }
  window.__nativeDone = function (id, payload) {
    const f = pending[id];
    if (f) { delete pending[id]; f(payload); }
  };
  function nativeTool(name, args) {
    return new Promise(function (res) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { status: 'failed', error: String(p) }; }
        res(o);
      });
      A.tool(id, name, JSON.stringify(args || {}));
    });
  }
  function nativeText(kind, text) {
    return new Promise(function (res, rej) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { ok: false, text: String(p) }; }
        if (o.ok) res(o.text); else rej(new Error(o.text));
      });
      if (kind === 'chat') A.chat(id, text); else A.ask(id, text);
    });
  }
  window.nativeTool = nativeTool;

  let liveActive = false;
  const toast = function (m) { try { showToast(m); } catch (e) {} };

  // ---- events pushed from the native live session -------------------------
  window.__miraNative = {
    state: function (s) {
      liveActive = !(s === 'IDLE' || s === 'ERROR');
      if (s === 'SPEAKING') {
        avatarState.speaking = true;
        setAvatarStatus('SPEAKING');
      } else {
        avatarState.speaking = false;
        window.__nativeLevel = null;
        if (s === 'LISTENING') {
          isTalkingActive = true; avatarState.listening = true;
          updateTalkSwitchUI();
          setAvatarStatus('LISTENING · SPEAK NOW');
          setLiveMicTranscriptText('🔴 Live — just speak, I am listening', true);
        } else if (s === 'THINKING') {
          setAvatarStatus('THINKING');
        } else if (s === 'CONNECTING') {
          setAvatarStatus('CONNECTING');
        } else {
          isTalkingActive = false; avatarState.listening = false;
          updateTalkSwitchUI();
          setAvatarStatus(s === 'ERROR' ? 'OFFLINE' : 'ACTIVE · READY');
          setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
        }
      }
    },
    user: function (t, fin) {
      if (fin) { if (t) appendChatMessage('user', t); }
      else setLiveMicTranscriptText('🔴 Heard: "' + t + '"', true);
    },
    asst: function (t, fin) { if (fin && t) appendChatMessage('jarvis', t); },
    level: function (m, s) { window.__nativeLevel = avatarState.speaking ? s : null; },
    error: function (m) { toast('⚠️ ' + m); try { appendChatMessage('sys', '⚠️ ' + m); } catch (e) {} },
    memory: function (cat, key, val) {
      try {
        const text = key.replace(/_/g, ' ') + ': ' + val;
        const emb = computeSemanticVector(text + ' ' + cat);
        memories.unshift({
          id: 'm_' + Date.now(), cat: 'Project', text: text,
          ts: new Date().toISOString().slice(0, 10), vec: Array.from(emb.vec), norm: emb.norm
        });
        persistSqliteDatabase(); renderMemories();
      } catch (e) {}
    },
    ttsDone: function () {
      avatarState.speaking = false;
      if (!liveActive) setAvatarStatus('ACTIVE · READY');
    }
  };

  // ---- voice: native Gemini Live replaces browser SpeechRecognition -------
  window.startTalking = function () {
    if (isTalkingActive) return;
    isTalkingActive = true;
    avatarState.listening = true;
    avatarState.speaking = false;
    updateTalkSwitchUI();
    setAvatarStatus('CONNECTING');
    setLiveMicTranscriptText('🔴 Connecting live voice…', true);
    syncNativeSettings();
    A.liveStart();
  };
  window.stopTalking = function () {
    isTalkingActive = false;
    avatarState.listening = false;
    avatarState.speaking = false;
    window.__nativeLevel = null;
    updateTalkSwitchUI();
    setAvatarStatus('ACTIVE · READY');
    setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
    A.liveStop();
  };

  // ---- spoken replies for typed chat (device voice) ------------------------
  window.speakJarvisReply = function (text) {
    if (!text || !hudAudioEnabled || liveActive) return;
    const clean = String(text).replace(/[*#`_~]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean) return;
    avatarState.speaking = true;
    setAvatarStatus('SPEAKING');
    A.speak(clean);
  };

  // ---- typed chat: native agent with every phone tool ----------------------
  const origSend = window.sendChatCommand;
  window.sendChatCommand = async function () {
    const inp = document.getElementById('chat-input');
    const text = ((inp && inp.value) || '').trim();
    if (!text) return;
    if (!A.getApiKey() && !getGeminiApiKey()) return origSend();
    inp.value = '';
    playHudBeep(580, 0.04);
    appendChatMessage('user', text);
    if (liveActive) { A.liveText(text); return; }
    syncNativeSettings();
    setAvatarStatus('THINKING · GEMINI');
    try {
      const reply = await nativeText('chat', text);
      appendChatMessage('jarvis', reply);
      speakJarvisReply(reply);
      if (!avatarState.speaking) setAvatarStatus('ACTIVE · READY');
    } catch (e) {
      appendChatMessage('jarvis', '⚠️ ' + e.message);
      setAvatarStatus('ACTIVE · READY');
    }
  };

  function syncNativeSettings() {
    try { A.syncSettings(getGeminiApiKey() || '', getAssistantName(), getUserName()); } catch (e) {}
  }
  const origSave = window.saveEngineConfig;
  window.saveEngineConfig = function () { origSave(); syncNativeSettings(); };

  // ---- real phone actions ---------------------------------------------------
  function report(title, r) {
    const ok = r && r.status !== 'failed' && r.status !== 'declined';
    appendChatMessage('jarvis', ok ? title + ' — ' + (r.status || 'done') : title + ' — ' + (r.error || r.status));
    return ok;
  }

  const origOpenApp = window.openNativeAndroidApp;
  window.openNativeAndroidApp = function (appKey, q) {
    const app = (typeof ANDROID_APP_SCHEMES !== 'undefined' && ANDROID_APP_SCHEMES[appKey]) || { title: appKey };
    undoStack.push({ title: 'Open Android App: ' + app.title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    let p;
    if (appKey === 'youtube' && q) p = nativeTool('youtube_video', { action: 'search', query: q });
    else if (appKey === 'maps' && q) p = nativeTool('browser_control', { action: 'maps_search', query: q });
    else if (appKey === 'chrome' && q && /^https?:/i.test(q)) p = nativeTool('browser_control', { action: 'open_url', url: q });
    else p = nativeTool('open_app', { app_name: app.title });
    p.then(function (r) {
      if (!report('Opening ' + app.title, r)) origOpenApp(appKey, q);
    });
  };

  const origComms = window.launchAndroidComms;
  window.launchAndroidComms = function (mode, target, msg) {
    const t = (target || '').trim(), m = (msg || '').trim();
    let call = null, title = '';
    if (mode === 'whatsapp_msg' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'whatsapp' }]; title = 'WhatsApp to ' + t; }
    else if (mode === 'sms' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'sms' }]; title = 'SMS to ' + t; }
    else if (mode === 'phone_call' && t) { call = ['make_call', { receiver: t }]; title = 'Call ' + t; }
    if (!call) return origComms(mode, target, msg);
    undoStack.push({ title: title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    nativeTool(call[0], call[1]).then(function (r) {
      if (!report(title, r)) origComms(mode, target, msg);
    });
  };

  window.toggleMobileFlashlight = async function (force) {
    const action = force === true ? 'flashlight_on' : (force === false ? 'flashlight_off' : 'flashlight_toggle');
    const r = await nativeTool('phone_settings', { action: action });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : '🔦 Flashlight ' + (r.flashlight || 'toggled'));
  };

  let soundIdx = 0;
  window.cycleSoundProfile = async function () {
    const modes = [['ringer_normal', '🔔 Normal'], ['ringer_vibrate', '📳 Vibrate'], ['ringer_silent', '🔕 Silent']];
    soundIdx = (soundIdx + 1) % modes.length;
    const r = await nativeTool('phone_settings', { action: modes[soundIdx][0] });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : modes[soundIdx][1]);
    appendChatMessage('jarvis', 'Sound profile: ' + modes[soundIdx][1] + (r.status === 'failed' ? ' (' + r.error + ')' : ''));
  };

  window.startQuickMobileAlarm = async function (seconds, label) {
    const s = seconds || 10;
    const r = await nativeTool('set_alarm_timer', { type: 'timer', seconds: s, label: label || 'Mira' });
    report('Timer ' + s + 's', r);
    toast('⏰ Timer set: ' + s + 's');
  };

  window.triggerPhoneVibration = function () { try { A.vibrate(60); } catch (e) {} };

  window.exportMobileNoteFile = function () {
    const feed = document.getElementById('chat-feed');
    const content = [
      '=== ' + getAssistantName().toUpperCase() + ' MOBILE REPORT ===',
      'Owner: ' + getUserName(),
      'Time: ' + new Date().toLocaleString(),
      '',
      'Stored Memories:'
    ].concat(memories.map(function (m) { return '- [' + m.cat + '] ' + m.text + ' (' + m.ts + ')'; }))
      .concat(['', 'Chat log:', feed ? feed.innerText : '']).join('\n');
    const name = getAssistantName().toLowerCase() + '_report_' + Date.now() + '.txt';
    const path = A.saveNote(name, content);
    appendChatMessage('jarvis', '📥 Saved to: ' + path);
    toast('📥 Saved: ' + name);
  };

  // ---- real hardware telemetry ---------------------------------------------
  window.updateHardwareTelemetry = async function () {
    const clockEl = document.getElementById('clock-txt');
    if (clockEl) clockEl.textContent = new Date().toTimeString().slice(0, 5);
    let s;
    try { s = JSON.parse(A.status()); } catch (e) { return; }
    const set = function (id, v) { const el = document.getElementById(id); if (el) el.textContent = v; };
    const bar = function (id, v) { const el = document.getElementById(id); if (el) el.style.width = Math.max(1, Math.min(100, v)) + '%'; };
    set('tel-cores-val', s.cores + ' Cores');
    set('tel-ram-gb', s.ramGb + ' GB');
    set('tel-heap-mb', 'Heap: ' + s.heapMb + ' MB');
    try { set('tel-frame-ms', smoothedRenderMs.toFixed(1) + ' ms/f'); } catch (e) {}
    set('tel-source-lbl', 'SOURCE: ANDROID NATIVE SENSORS (LIVE)');
    if (s.cpu >= 0) { set('metric-cpu', s.cpu + '%'); bar('bar-cpu', s.cpu); }
    set('metric-ram', s.ram + '%'); bar('bar-ram', s.ram);
    try { renderBatteryUi(s.bat, !!s.charging); } catch (e) {}
  };

  // ---- real notification filter ----------------------------------------------
  const origOpenNotifs = window.openSmartNotificationsModal;
  window.openSmartNotificationsModal = function () {
    if (!A.notificationAccess()) {
      toast('Allow Notification access for Mira, then reopen this');
      A.openNotifAccess();
      return origOpenNotifs();
    }
    try { phoneNotifications = JSON.parse(A.notifications()); } catch (e) {}
    origOpenNotifs();
    const imp = phoneNotifications.filter(function (n) { return n.isImportant; });
    const box = document.getElementById('notif-summary-text');
    if (!phoneNotifications.length) {
      if (box) box.textContent = 'এখনো কোনো নোটিফিকেশন ধরা পড়েনি। নতুন নোটিফিকেশন এলে এখানে দেখা যাবে।';
      return;
    }
    if (box) box.textContent = '…';
    const brief = imp.slice(0, 12).map(function (n) { return n.app + ' / ' + n.sender + ': ' + n.title + ' ' + n.desc; }).join('\n');
    nativeText('ask', 'এই ফোনে মোট ' + phoneNotifications.length + 'টি নোটিফিকেশন, ' + imp.length + 'টি দরকারি। বাংলায় ২টি ছোট বাক্যে সারাংশ দাও, শুধু দরকারিগুলো নিয়ে (ব্যাংক, OTP, পরিবার)। কোনো OTP কোড পড়ে শোনাবে না।\n' + (brief || '(কোনোটিই দরকারি নয়)'))
      .then(function (t) { if (box) box.textContent = t; })
      .catch(function () { if (box) box.textContent = phoneNotifications.length + 'টি নোটিফিকেশনের মধ্যে ' + imp.length + 'টি দরকারি।'; });
  };

  // ---- first-run wiring -----------------------------------------------------------
  function init() {
    try {
      const nk = A.getApiKey();
      if (nk && !localStorage.getItem('mira_gemini_api_key')) {
        localStorage.setItem('mira_gemini_api_key', nk);
        const f = document.getElementById('cfg-gemini-key');
        if (f) f.value = nk;
      }
    } catch (e) {}
    syncNativeSettings();
    try {
      A.importMemories(JSON.stringify(memories.map(function (m) { return { id: m.id, cat: m.cat, text: m.text }; })));
    } catch (e) {}
    const sv = document.getElementById('view-settings');
    if (sv && !document.getElementById('native-perm-card')) {
      const d = document.createElement('div');
      d.id = 'native-perm-card';
      d.className = 'hud-card rounded-3xl p-4 space-y-2';
      d.innerHTML = '<div class="text-xs font-semibold text-white">Phone Control Permissions</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Accessibility (taps, typing, screenshots), All files, Display over apps, Notification access, Battery, Exact alarms.</p>' +
        '<button class="w-full py-2.5 rounded-xl btn-minimal text-xs font-semibold" onclick="Android.openNativeSettings()">📱 Open Native Permissions</button>';
      sv.appendChild(d);
    }
    try { A.pageReady(); } catch (e) {}
  }
  if (document.readyState === 'complete') setTimeout(init, 400);
  else window.addEventListener('load', function () { setTimeout(init, 400); });
})();
