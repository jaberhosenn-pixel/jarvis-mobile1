package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** File tools (mobile twins of actions/file_controller.py and actions/file_processor.py). */
public final class ToolsFiles {
    private ToolsFiles() {}

    static void register() {
        reg("file_controller",
                "Manages files and folders on the phone's shared storage: list, create_file, create_folder, delete (moved to a trash folder, "
                        + "needs on-screen approval), move, copy, rename, read, write, find, largest, disk_usage, info. "
                        + "Paths may be relative shortcuts: downloads, documents, dcim (camera photos), pictures, music, movies, home. "
                        + "Needs the 'All files access' permission.",
                schema("action",
                        "action:STRING:list | create_file | create_folder | delete | move | copy | rename | read | write | find | largest | disk_usage | info",
                        "path:STRING:file or folder path or shortcut, e.g. downloads/report.txt",
                        "destination:STRING:destination path for move/copy",
                        "new_name:STRING:new name for rename",
                        "content:STRING:text for create_file/write",
                        "name:STRING:file name fragment to search for",
                        "extension:STRING:extension to search, e.g. .pdf",
                        "count:INTEGER:number of results for largest"),
                (c, a) -> fileController(c, a));

        reg("file_processor",
                "Reads and summarises a document: txt, md, csv, json, docx, pptx, xlsx, pdf, or an image. "
                        + "Give the path (or a shortcut like downloads/file.pdf) and optionally a question about it.",
                schema("path",
                        "path:STRING:file path",
                        "question:STRING:what to find out; empty means summarise"),
                (c, a) -> fileProcessor(c, a));
    }

    // ------------------------------------------------------------------ paths

    public static File jarvisDir(Context c) {
        File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Jarvis");
        if (!d.exists() && !d.mkdirs()) {
            d = c.getExternalFilesDir(null);
            if (d == null) d = c.getFilesDir();
        }
        return d;
    }

    private static boolean hasAllFiles() {
        return Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
    }

    private static File root() {
        return Environment.getExternalStorageDirectory();
    }

    private static File resolve(String p) {
        if (p == null || p.trim().isEmpty()) return root();
        String s = p.trim();
        String lower = s.toLowerCase(Locale.ROOT);
        String[][] map = {
                {"downloads", Environment.DIRECTORY_DOWNLOADS}, {"download", Environment.DIRECTORY_DOWNLOADS},
                {"documents", Environment.DIRECTORY_DOCUMENTS}, {"document", Environment.DIRECTORY_DOCUMENTS},
                {"dcim", Environment.DIRECTORY_DCIM}, {"camera", Environment.DIRECTORY_DCIM},
                {"pictures", Environment.DIRECTORY_PICTURES}, {"photos", Environment.DIRECTORY_PICTURES},
                {"music", Environment.DIRECTORY_MUSIC}, {"movies", Environment.DIRECTORY_MOVIES},
                {"videos", Environment.DIRECTORY_MOVIES}, {"desktop", Environment.DIRECTORY_DOCUMENTS}
        };
        for (String[] m : map) {
            if (lower.equals(m[0]) || lower.startsWith(m[0] + "/")) {
                File base = Environment.getExternalStoragePublicDirectory(m[1]);
                String rest = s.length() > m[0].length() ? s.substring(m[0].length() + 1) : "";
                return rest.isEmpty() ? base : new File(base, rest);
            }
        }
        if (lower.equals("home") || lower.equals("storage") || lower.equals("sdcard")) return root();
        if (s.startsWith("/")) return new File(s);
        return new File(root(), s);
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return (b / 1024) + " KB";
        if (b < 1073741824L) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    // ------------------------------------------------------------------ file_controller

    private static JSONObject fileController(final Context c, JSONObject a) throws Exception {
        if (!hasAllFiles()) {
            if (Build.VERSION.SDK_INT >= 30) {
                Util.launch(c, new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + c.getPackageName())));
            }
            return J.fail("File access is not granted. I opened the page; ask the user to allow 'All files access' for Jarvis.");
        }
        String act = a.optString("action").toLowerCase(Locale.ROOT);
        File f = resolve(a.optString("path"));

        switch (act) {
            case "list": {
                File[] kids = f.listFiles();
                if (kids == null) return J.fail("cannot list " + f.getPath());
                Arrays.sort(kids, Comparator.comparing(x -> x.getName().toLowerCase(Locale.ROOT)));
                JSONArray out = new JSONArray();
                for (int i = 0; i < kids.length && i < 80; i++) {
                    out.put(J.obj("name", kids[i].getName(), "dir", kids[i].isDirectory(),
                            "size", kids[i].isDirectory() ? "" : size(kids[i].length())));
                }
                return J.ok("path", f.getPath(), "count", kids.length, "items", J.untrusted("filenames", out.toString()));
            }
            case "info": {
                if (!f.exists()) return J.fail("not found: " + f.getPath());
                return J.ok("path", f.getPath(), "dir", f.isDirectory(), "size", size(f.length()),
                        "modified", new java.util.Date(f.lastModified()).toString());
            }
            case "read": {
                if (!f.isFile()) return J.fail("not a file: " + f.getPath());
                return J.ok("content", J.untrusted("file:" + f.getName(), readText(f, 8000)));
            }
            case "create_file":
            case "write": {
                final boolean existed = f.exists();
                final byte[] old = existed && f.isFile() && f.length() < 2000000 ? readBytes(f) : null;
                if (f.getParentFile() != null) f.getParentFile().mkdirs();
                try (FileOutputStream fo = new FileOutputStream(f)) {
                    fo.write(a.optString("content").getBytes("UTF-8"));
                }
                final File ff = f;
                Util.pushUndo((existed ? "write to " : "create ") + f.getName(), () -> {
                    try {
                        if (!existed) {
                            ff.delete();
                        } else if (old != null) {
                            try (FileOutputStream fo = new FileOutputStream(ff)) {
                                fo.write(old);
                            }
                        }
                    } catch (Exception ignored) {
                    }
                });
                return J.ok("path", f.getPath());
            }
            case "create_folder": {
                boolean ok = f.mkdirs();
                final File ff = f;
                if (ok) Util.pushUndo("create folder " + f.getName(), () -> ff.delete());
                return ok ? J.ok("path", f.getPath()) : J.fail("could not create (exists already?)");
            }
            case "delete": {
                if (!f.exists()) return J.fail("not found: " + f.getPath());
                if (!Bus.confirm("Delete " + f.getPath() + "?\n(It will go to the Jarvis trash folder and can be undone.)")) {
                    return J.obj("status", "declined", "note", "the user did not approve on screen");
                }
                File trash = new File(root(), ".jarvis_trash");
                trash.mkdirs();
                final File dest = new File(trash, System.currentTimeMillis() + "_" + f.getName());
                final File src = f;
                if (!f.renameTo(dest)) return J.fail("could not move to trash");
                Util.pushUndo("delete " + src.getName(), () -> dest.renameTo(src));
                return J.ok("moved_to_trash", dest.getPath());
            }
            case "move":
            case "rename": {
                if (!f.exists()) return J.fail("not found: " + f.getPath());
                File dest;
                if (act.equals("rename")) {
                    String nn = a.optString("new_name");
                    if (nn.isEmpty()) return J.fail("new_name is empty");
                    dest = new File(f.getParentFile(), nn);
                } else {
                    dest = resolve(a.optString("destination"));
                    if (dest.isDirectory()) dest = new File(dest, f.getName());
                }
                if (dest.exists()) return J.fail("destination already exists");
                if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
                final File src = f;
                final File dd = dest;
                if (!f.renameTo(dest)) return J.fail("move failed");
                Util.pushUndo(act + " " + src.getName(), () -> dd.renameTo(src));
                return J.ok("now_at", dest.getPath());
            }
            case "copy": {
                if (!f.isFile()) return J.fail("only single files can be copied");
                File dest = resolve(a.optString("destination"));
                if (dest.isDirectory()) dest = new File(dest, f.getName());
                if (dest.exists()) return J.fail("destination already exists");
                if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
                try (InputStream in = new FileInputStream(f); FileOutputStream out = new FileOutputStream(dest)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                final File dd = dest;
                Util.pushUndo("copy " + f.getName(), () -> dd.delete());
                return J.ok("copied_to", dest.getPath());
            }
            case "find": {
                String name = Util.lower(a.optString("name"));
                String ext = Util.lower(a.optString("extension"));
                List<File> hits = new ArrayList<>();
                File start = a.optString("path").isEmpty() ? root() : f;
                walk(start, name, ext, hits, 0);
                JSONArray out = new JSONArray();
                for (int i = 0; i < hits.size() && i < 30; i++) {
                    out.put(J.obj("path", hits.get(i).getPath(), "size", size(hits.get(i).length())));
                }
                return J.ok("found", hits.size(), "results", J.untrusted("filenames", out.toString()));
            }
            case "largest": {
                List<File> all = new ArrayList<>();
                walk(a.optString("path").isEmpty() ? root() : f, "", "", all, 0);
                all.sort((x, y) -> Long.compare(y.length(), x.length()));
                int n = Math.max(1, Math.min(20, a.optInt("count", 5)));
                JSONArray out = new JSONArray();
                for (int i = 0; i < all.size() && i < n; i++) {
                    out.put(J.obj("path", all.get(i).getPath(), "size", size(all.get(i).length())));
                }
                return J.ok("largest", J.untrusted("filenames", out.toString()));
            }
            case "disk_usage": {
                StatFs fs = new StatFs(root().getPath());
                return J.ok("total", size(fs.getTotalBytes()), "free", size(fs.getAvailableBytes()),
                        "used", size(fs.getTotalBytes() - fs.getAvailableBytes()));
            }
            default:
                return J.fail("unknown action '" + act + "'");
        }
    }

    private static void walk(File dir, String name, String ext, List<File> out, int depth) {
        if (depth > 6 || out.size() > 3000) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.getName().startsWith(".")) continue;
            if (k.isDirectory()) {
                if (k.getPath().contains("/Android/data") || k.getPath().contains("/Android/obb")) continue;
                walk(k, name, ext, out, depth + 1);
            } else {
                String n = k.getName().toLowerCase(Locale.ROOT);
                if ((name.isEmpty() || n.contains(name)) && (ext.isEmpty() || n.endsWith(ext))) out.add(k);
            }
        }
    }

    private static byte[] readBytes(File f) {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private static String readText(File f, int max) {
        byte[] b = readBytes(f);
        if (b == null) return "";
        String s = new String(b, java.nio.charset.StandardCharsets.UTF_8);
        return s.length() > max ? s.substring(0, max) + "\n[truncated]" : s;
    }

    // ------------------------------------------------------------------ file_processor

    private static String zipXmlText(File f, String... prefixes) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (ZipInputStream z = new ZipInputStream(new FileInputStream(f))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                boolean want = false;
                for (String p : prefixes) if (e.getName().startsWith(p) && e.getName().endsWith(".xml")) want = true;
                if (!want) continue;
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = z.read(buf)) > 0) bo.write(buf, 0, n);
                String xml = bo.toString("UTF-8");
                xml = xml.replaceAll("</(w:p|a:p|row|si)>", "\n").replaceAll("(?s)<[^>]+>", " ").replaceAll("[ \\t]+", " ");
                sb.append(xml).append('\n');
                if (sb.length() > 30000) break;
            }
        }
        return sb.toString().trim();
    }

    private static JSONObject fileProcessor(Context c, JSONObject a) throws Exception {
        if (!hasAllFiles()) return J.fail("File access is not granted. Ask the user to allow 'All files access' for Jarvis in Settings.");
        File f = resolve(a.optString("path"));
        if (!f.isFile()) return J.fail("not a file: " + f.getPath());
        String q = a.optString("question", "").trim();
        String n = f.getName().toLowerCase(Locale.ROOT);
        String ask = q.isEmpty() ? "Summarise this document concisely." : q;

        if (n.endsWith(".pdf") || n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp")
                || n.endsWith(".mp3") || n.endsWith(".wav")) {
            if (f.length() > 15000000L) return J.fail("file too large (15 MB limit)");
            String mime = n.endsWith(".pdf") ? "application/pdf" : n.endsWith(".png") ? "image/png"
                    : n.endsWith(".webp") ? "image/webp" : n.endsWith(".mp3") ? "audio/mp3" : n.endsWith(".wav") ? "audio/wav" : "image/jpeg";
            String r = GeminiRest.generateMedia(c, ask, false, readBytes(f), mime, null);
            return J.ok("file", f.getName(), "answer", J.untrusted("file:" + f.getName(), r));
        }

        String text;
        if (n.endsWith(".docx")) text = zipXmlText(f, "word/document");
        else if (n.endsWith(".pptx")) text = zipXmlText(f, "ppt/slides/slide");
        else if (n.endsWith(".xlsx")) text = zipXmlText(f, "xl/sharedStrings");
        else text = readText(f, 30000);
        if (text.isEmpty()) return J.fail("could not read any text from this file");
        if (text.length() > 30000) text = text.substring(0, 30000);
        String r = GeminiRest.generate(c, ask + "\n\nDocument:\n" + text);
        return J.ok("file", f.getName(), "answer", J.untrusted("file:" + f.getName(), r));
    }
}
