package com.markvi.jarvis;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/** Settings: API key, voice, behaviour, and the one-tap permission shortcuts Android requires. */
public class SettingsActivity extends Activity {

    private EditText key;
    private EditText name;
    private EditText model;
    private Spinner voice;
    private Switch interrupt;
    private Switch thinking;
    private Switch awake;
    private LinearLayout permBox;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.parseColor("#00E5FF"));
        t.setTextSize(12);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.parseColor("#557078"));
        e.setSingleLine(true);
        return e;
    }

    private Switch sw(String text, boolean on) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setChecked(on);
        s.setTextColor(Color.WHITE);
        s.setPadding(0, dp(8), 0, dp(8));
        return s;
    }

    private Button action(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Jarvis settings");
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#03080F"));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(24), dp(18), dp(40));
        sv.addView(col);

        TextView h = new TextView(this);
        h.setText("SETTINGS");
        h.setTextColor(Color.WHITE);
        h.setTextSize(22);
        col.addView(h);

        col.addView(label("GEMINI API KEY"));
        key = field("paste your key", Prefs.apiKey(this));
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        col.addView(key);
        col.addView(action("Get a free key (opens browser)", v -> startActivity(
                new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))));
        col.addView(action("Test the key", v -> testKey()));

        col.addView(label("ASSISTANT"));
        name = field("assistant name", Prefs.assistantName(this));
        col.addView(name);
        voice = new Spinner(this);
        voice.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Prefs.VOICES));
        String cur = Prefs.voice(this);
        for (int i = 0; i < Prefs.VOICES.length; i++) if (Prefs.VOICES[i].equals(cur)) voice.setSelection(i);
        col.addView(voice);
        model = field("Live model override (leave empty for automatic)", Prefs.model(this));
        col.addView(model);

        col.addView(label("BEHAVIOUR"));
        interrupt = sw("Let me interrupt by speaking (use headphones)", Prefs.allowInterrupt(this));
        thinking = sw("Deeper thinking (slower)", Prefs.thinking(this));
        awake = sw("Keep the CPU awake during a session", Prefs.keepAwake(this));
        col.addView(interrupt);
        col.addView(thinking);
        col.addView(awake);

        col.addView(label("PERMISSIONS ANDROID ASKS YOU TO GRANT"));
        permBox = new LinearLayout(this);
        permBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(permBox);

        col.addView(label("MEMORY"));
        col.addView(action("Show what Jarvis remembers", v -> showMemory()));
        col.addView(action("Forget everything", v -> new AlertDialog.Builder(this)
                .setMessage("Erase all long-term memory?")
                .setPositiveButton("Erase", (d, w) -> Memory.clear(this))
                .setNegativeButton("Cancel", null).show()));

        TextView foot = new TextView(this);
        foot.setText("\nMark LVI mobile port. Voice runs on the Gemini Live API; tools run on your phone.");
        foot.setTextColor(Color.parseColor("#5A8E99"));
        foot.setTextSize(11);
        col.addView(foot);

        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissions();
    }

    @Override
    protected void onPause() {
        save();
        super.onPause();
    }

    private void save() {
        Prefs.setApiKey(this, key.getText().toString());
        Prefs.sp(this).edit()
                .putString("assistant_name", name.getText().toString().trim())
                .putString("voice", String.valueOf(voice.getSelectedItem()))
                .putString("model", model.getText().toString().trim())
                .putBoolean("allow_interrupt", interrupt.isChecked())
                .putBoolean("thinking", thinking.isChecked())
                .putBoolean("keep_awake", awake.isChecked())
                .apply();
    }

    private void refreshPermissions() {
        permBox.removeAllViews();
        boolean acc = JarvisAccessibility.get() != null;
        addPerm("Notification access (Smart Notification Filter)", new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        addPerm("Accessibility control (taps, typing, screenshots): " + (acc ? "ON" : "OFF"),
                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));

        boolean files = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
        addPerm("All files access (file tools): " + (files ? "ON" : "OFF"),
                Build.VERSION.SDK_INT >= 30
                        ? new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))
                        : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));

        addPerm("Display over other apps (open apps while in background): " + (Settings.canDrawOverlays(this) ? "ON" : "OFF"),
                new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));

        addPerm("Modify system settings (brightness): " + (Settings.System.canWrite(this) ? "ON" : "OFF"),
                new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        addPerm("Unrestricted battery (keeps Jarvis alive): " + (pm.isIgnoringBatteryOptimizations(getPackageName()) ? "ON" : "OFF"),
                new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));

        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            addPerm("Exact alarms (on-time reminders): " + (am.canScheduleExactAlarms() ? "ON" : "OFF"),
                    new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
        }
        addPerm("Do Not Disturb access", new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        addPerm("App permissions (microphone, contacts, calls, SMS, camera)",
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
    }

    private void addPerm(String text, final Intent intent) {
        Button b = action(text, v -> {
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "This page is not available on your phone", Toast.LENGTH_SHORT).show();
            }
        });
        b.setTextSize(12);
        permBox.addView(b);
    }

    private void showMemory() {
        JSONArray all = Memory.all(this);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null) continue;
            sb.append(o.optString("category")).append(" / ").append(o.optString("key")).append(": ")
                    .append(o.optString("value")).append('\n');
        }
        new AlertDialog.Builder(this)
                .setTitle("Memory")
                .setMessage(sb.length() == 0 ? "(empty)" : sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private void testKey() {
        save();
        Toast.makeText(this, "Testing...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                String r = GeminiRest.generate(this, "Reply with the single word OK.");
                msg = "Key works: " + GeminiRest.abbreviate(r, 30);
            } catch (Exception e) {
                msg = "Key problem: " + GeminiRest.abbreviate(String.valueOf(e.getMessage()), 140);
            }
            final String m = msg;
            ui.post(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        }).start();
    }
}
