package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires a reminder: notification, and a spoken alert when a live session is running. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String msg = i.getStringExtra("msg");
        int id = i.getIntExtra("id", 1);
        if (msg == null) msg = "Reminder";
        Util.notifyAlert(c, id, "Reminder", msg);
        JarvisService s = JarvisService.get();
        if (s != null && s.isLive()) s.alert("Reminder due now: " + msg);
    }
}
