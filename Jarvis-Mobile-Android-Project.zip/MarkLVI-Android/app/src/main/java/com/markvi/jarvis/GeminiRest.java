package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** One-shot Gemini text calls (mobile twin of core/gemini.py) plus plain HTTP GET. */
public final class GeminiRest {
    private GeminiRest() {}

    public static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String[] LADDER = {"gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-latest"};

    /**
     * @param search    ground the answer with Google Search
     * @param imageJpeg optional JPEG bytes to look at
     * @param youtubeUrl optional YouTube URL for Gemini to watch
     */
    public static String generate(Context c, String prompt, boolean search, byte[] imageJpeg, String youtubeUrl)
            throws Exception {
        return generateMedia(c, prompt, search, imageJpeg, "image/jpeg", youtubeUrl);
    }

    /** Same as generate() but the attached bytes may be any type Gemini reads (PDF, PNG, audio...). */
    public static String generateMedia(Context c, String prompt, boolean search, byte[] media, String mime,
                                       String youtubeUrl) throws Exception {
        String key = Prefs.apiKey(c);
        if (key.isEmpty()) throw new Exception("No Gemini API key set. Open Settings and paste one.");

        JSONArray parts = new JSONArray();
        if (youtubeUrl != null && !youtubeUrl.isEmpty()) {
            parts.put(J.obj("file_data", J.obj("file_uri", youtubeUrl)));
        }
        if (media != null) {
            parts.put(J.obj("inline_data", J.obj("mime_type", mime,
                    "data", android.util.Base64.encodeToString(media, android.util.Base64.NO_WRAP))));
        }
        parts.put(J.obj("text", prompt));

        JSONObject body = J.obj("contents", J.arr(J.obj("parts", parts)));
        if (search) J.put(body, "tools", J.arr(J.obj("google_search", new JSONObject())));

        Exception last = null;
        for (String model : LADDER) {
            try {
                Request req = new Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/" + model
                                + ":generateContent?key=" + key)
                        .post(RequestBody.create(body.toString(), JSON))
                        .build();
                try (Response r = HTTP.newCall(req).execute()) {
                    String txt = r.body() == null ? "" : r.body().string();
                    if (!r.isSuccessful()) {
                        last = new Exception("HTTP " + r.code() + " " + abbreviate(txt, 200));
                        if (r.code() == 400 || r.code() == 401 || r.code() == 403) throw last;
                        continue;
                    }
                    JSONObject o = J.parse(txt);
                    JSONArray cands = o.optJSONArray("candidates");
                    if (cands == null || cands.length() == 0) {
                        last = new Exception("empty answer");
                        continue;
                    }
                    JSONObject content = cands.getJSONObject(0).optJSONObject("content");
                    if (content == null) {
                        last = new Exception("blocked or empty answer");
                        continue;
                    }
                    JSONArray ps = content.optJSONArray("parts");
                    StringBuilder sb = new StringBuilder();
                    if (ps != null) {
                        for (int i = 0; i < ps.length(); i++) sb.append(ps.getJSONObject(i).optString("text", ""));
                    }
                    String out = sb.toString().trim();
                    if (!out.isEmpty()) return out;
                    last = new Exception("empty text");
                }
            } catch (Exception e) {
                last = e;
                String m = String.valueOf(e.getMessage());
                if (m.startsWith("HTTP 400") || m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) break;
            }
        }
        throw last != null ? last : new Exception("no model answered");
    }

    public static String generate(Context c, String prompt) throws Exception {
        return generate(c, prompt, false, null, null);
    }

    public static String httpGet(String url) throws Exception {
        Request req = new Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) JarvisMobile/6.0")
                .build();
        try (Response r = HTTP.newCall(req).execute()) {
            String t = r.body() == null ? "" : r.body().string();
            if (!r.isSuccessful()) throw new Exception("HTTP " + r.code());
            return t;
        }
    }

    public static String abbreviate(String s, int max) {
        if (s == null) return "";
        s = s.replace('\n', ' ');
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
